/* eslint-disable react/prop-types */

import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Autoplay } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";

const testimonials = [
  {
    id: 1,
    reviewer: "Chris",
    role: "President and CEO, PrintReach, USA",
    review:
      "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat aute irure sint amet occaecat cupidatat non proident.",
    rating: 4.5,
    profileImage: "https://via.placeholder.com/80", // Replace with actual image URL
  },
  {
    id: 2,
    reviewer: "Alex",
    role: "Founder, TechWorld, UK",
    review:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    rating: 5,
    profileImage: "https://via.placeholder.com/80",
  },
  {
    id: 3,
    reviewer: "Sophia",
    role: "Manager, CloudBase, USA",
    review:
      "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
    rating: 4,
    profileImage: "https://via.placeholder.com/80",
  },
  {
    id: 4,
    reviewer: "Michael",
    role: "CTO, InnovateX, Canada",
    review:
      "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    rating: 4.8,
    profileImage: "https://via.placeholder.com/80",
  },
  {
    id: 5,
    reviewer: "Emma",
    role: "Designer, Creatix, Germany",
    review:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.",
    rating: 5,
    profileImage: "https://via.placeholder.com/80",
  },
];


const StarRating = ({ rating }) => {
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 !== 0;
  const stars = Array.from({ length: 5 }, (_, index) => {
    if (index < fullStars) return "★";
    if (halfStar && index === fullStars) return "☆";
    return "☆";
  });
  return <div className="text-yellow-400">{stars.join(" ")}</div>;
};

const TestimonialSwiper = () => {
  return (
    <div className="bg-blue-900 text-white py-10 px-5 relative ">
      
      <h2 className="text-center text-2xl font-bold mb-6 relative">
        What People Say About Us
      </h2>
        {/* Navigation Arrows */}
        <div className="absolute top-12 right-24 flex text-sm space-x-2">
          <button className="swiper-button-prev bg-yellow-400 text-blue-900 w-8 h-8 flex items-center justify-center rounded-full shadow-lg">
           
          </button>
          <button className="swiper-button-next bg-yellow-400 text-blue-900 w-2 h-2 flex items-center justify-center rounded-full shadow-lg">
          
          </button>
        </div>
      <div className="max-w-6xl mx-auto relative">
         
        {/* Swiper with autoplay and navigation */}
        <Swiper
          modules={[Navigation, Pagination, Autoplay]}
          spaceBetween={30}
          slidesPerView={3}
          navigation={{
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          }}
          pagination={{ clickable: true }}
          // autoplay={{
          //   delay: 3000, // Autoplay every 3 seconds
          //   disableOnInteraction: false,
          // }}
          breakpoints={{
            640: { slidesPerView: 1, spaceBetween: 20 },
            768: { slidesPerView: 2, spaceBetween: 30 },
            1024: { slidesPerView: 3, spaceBetween: 30 },
          }}
        >
          {testimonials.map((testimonial) => (
            <SwiperSlide key={testimonial.id}>
              <div className="bg-white text-gray-900 p-6 rounded-lg shadow-lg">
                {/* Star Rating */}
                <div className="absolute top-4 right-4">
                  <StarRating rating={testimonial.rating} />
                </div>
                {/* Testimonial */}
                <blockquote className="mb-4">
                  <div className="text-yellow-500 text-2xl">“</div>
                  <p className="italic">{testimonial.review}</p>
                </blockquote>
                {/* Reviewer */}
                <div className="flex items-center mt-4">
                  <img
                    src={testimonial.profileImage}
                    alt={testimonial.reviewer}
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="text-lg font-bold">{testimonial.reviewer}</h4>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>

     

      
   
      </div>
    </div>
  );
};

export default TestimonialSwiper;
