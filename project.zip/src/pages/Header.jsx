import React from 'react';

const Header = () => {
  const links = [

    { href: 'tel:+918447746183', icon: '📞', label: '+918447746183' },
    { href: '#', icon: '📘', label: 'Facebook' },
    { href: '#', icon: '🐦', label: 'Twitter' },
 
  ];

  return (
    <header className="bg-[#204e82] text-white py-2">
      <div className="container mx-auto flex justify-between items-center px-4 flex-wrap">
        {/* Logo on the left side */}
        <div className="flex items-center space-x-2">
         
        </div>

        {/* Links on the right side */}
        <div className="flex gap-2 flex-wrap justify-end">
          {links.map((link, index) => (
            <a
              key={index}
              href={link.href}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 text-sm sm:text-base mx-2 hover:text-gray-300"
            >
              <span>{link.icon}</span>
              <span>{link.label}</span>
            </a>
          ))}
        </div>
      </div>
    </header>
  );
};

export default Header;
