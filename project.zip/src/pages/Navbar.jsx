import React from "react";

const Navbar = () => {
  const menuItems = ["Home", "Our Services", "Blog", "Contact Us", "About Us"];

  return (
    <nav className="bg-white shadow-md px-6 md:px-12 lg:px-20 py-4 flex items-center justify-between">
      {/* Logo */}
      <div className="flex items-center space-x-2">
        <img
          src="https://via.placeholder.com/40" // Replace with the actual logo
          alt="Logo"
          className="h-8 w-8 object-contain"
        />
        <span className="text-2xl font-bold text-blue-800">
          <span className="text-orange-500">Register</span>Karo
        </span>
      </div>

      {/* Navigation Links */}
      <div className="hidden md:flex space-x-8">
        {menuItems.map((item, index) => (
          <button
            key={index}
            className={`text-gray-700 hover:text-blue-800 font-medium ${
              item === "Our Services" ? "relative group" : ""
            }`}
          >
            {item}
            {/* Dropdown for 'Our Services' */}
            {item === "Our Services" && (
              <div className="absolute left-0 hidden mt-2 bg-white border rounded-md shadow-md group-hover:block">
                <ul className="text-sm text-gray-700">
                  <li className="px-4 py-2 hover:bg-gray-100">Service 1</li>
                  <li className="px-4 py-2 hover:bg-gray-100">Service 2</li>
                  <li className="px-4 py-2 hover:bg-gray-100">Service 3</li>
                </ul>
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Search Icon & Button */}
      <div className="flex items-center space-x-4">
        <button>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-5 w-5 text-gray-600 hover:text-blue-800"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
        </button>
        <button className="bg-orange-500 text-white py-2 px-4 rounded-md font-medium hover:bg-orange-600 transition">
          Talk An Expert
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
