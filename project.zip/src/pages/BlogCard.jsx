



// import React from 'react'

// const BlogCard = () => {
//     const blogs = [
//         {
//           id: 1,
//           author: 'Prabhesh Mishra',
//           date: '1 Jan 2023',
//           tag: 'Today',
//           title: 'Small business & Startup',
//           description: 'Like to know the secrets of transforming a 2-14 team into a 3x Super Bowl winning Dynasty?',
//         //   categories: ['Tax & Audit', 'Management'],
//         //   image: 'https://via.placeholder.com/400', // Replace with real image URLs
//         },
//         {
//           id: 2,
//           author: 'Mahesh Kumar',
//           date: '1 Jan 2023',
//           title: 'Scale-Up Company Offer',
//           description: 'Mental models are simple expressions of complex processes or relationships.',
//         //   categories: ['Tax', 'Research', 'Compliance'],
//         //   image: 'https://via.placeholder.com/400',
//         },
//         {
//           id: 3,
//           author: 'Rakhi Verma',
//           date: '1 Jan 2023',
//           title: 'Growing Business Package',
//           description: 'Introduction to Wireframing and Its Principles. Learn from the best in the Industry.',
//         //   categories: ['Audit', 'Money Back'],
//         //   image: 'https://via.placeholder.com/400',
//         },
//         {
//           id: 4,
//           author: 'Karan Kumar',
//           date: '1 Jan 2023',
//           title: 'Scale-Up Company Offer',
//           description: 'Collaboration can make our teams stronger, and our Individual designs better.',
//         //   categories: ['Money', 'Management'],
//         //   image: 'https://via.placeholder.com/400',
//         },
//         {
//           id: 5,
//           author: 'Richa Singh',
//           date: '1 Jan 2023',
//           title: 'Scale-Up Company Offer',
//           description: 'JavaScript frameworks make development easy with extensive features and functionalities.',
//         //   categories: ['Tax Return', 'News', 'Audit'],
//         //   image: 'https://via.placeholder.com/400',
//         },
//         {
//           id: 6,
//           author: 'Miss Nora',
//           date: '1 Jan 2023',
//           title: 'Scale-Up Company Offer',
//           description: 'Starting a community doesn\'t need to be complicated, but how do you get started?',
//         //   categories: ['Private Limited Company', 'Customer Success'],
//         //   image: 'https://via.placeholder.com/400',
//         },
//       ];
      
//   return (
//    <>
//     <div className="bg-gray-900 text-white py-10 px-5">
//       <h1 className="text-center text-3xl font-bold text-orange-500 mb-8">Explore Our Blogs</h1>
//       <h2 className="text-center text-2xl font-semibold text-gray-300 mb-10">Accelerate Digital Transformation</h2>
//       <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
//         {blogs.map((blog) => (
//           <BlogCard key={blog.id} blog={blog} />
//         ))}
//       </div>
//       <div className="text-center mt-8">
//         <button className="bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2 px-4 rounded">
//           Show more blogs
//         </button>
//       </div>
//     </div>
   
//    </>
//   )
// }

// export default BlogCard

