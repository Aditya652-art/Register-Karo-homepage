import React from "react";

const WhyChooseUs = () => {
  const cards = [
    {
      title: "Confidential & Safe",
      description: "All your private information is safe with us",
      bgColor: "bg-orange-100",
      icon: "🛡️",
    },
    {
      title: "No Hidden Fee",
      description: "Everything is put before you with no hidden charges or conditions",
      bgColor: "bg-green-100",
      icon: "✅",
    },
    {
      title: "Guaranteed Satisfaction",
      description: "We ensure that you stay 100% satisfied with our offered services",
      bgColor: "bg-blue-100",
      icon: "😊",
    },
    {
      title: "Expert CA/CS Assistance",
      description: "Prompt support from our in-house expert professionals",
      bgColor: "bg-pink-100",
      icon: "👨‍💼",
    },
    {
      title: "Confidential & Safe",
      description: "All your private information is safe with us",
      bgColor: "bg-orange-100",
      icon: "🛡️",
    },
  ];

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-lg font-semibold text-orange-500 uppercase mb-2">
          WHY REGISTERKARO.IN
        </h2>
        <h3 className="text-3xl font-bold text-gray-800 mb-4">
          Why Choose Register Karo
        </h3>
        <p className="text-gray-600 mb-8 max-w-2xl">
          It is with consistent services and results that build trust with the people and that in
          turn help us to serve the business better.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="flex flex-col justify-center">
            <div className="space-y-6">
              {cards.slice(0, 2).map((card, index) => (
                <div
                  key={index}
                  className={`p-6 rounded-lg shadow-md ${card.bgColor} flex flex-col items-start`}
                >
                  <div className="text-4xl mb-4">{card.icon}</div>
                  <h4 className="text-xl font-semibold text-gray-800 mb-2">
                    {card.title}
                  </h4>
                  <p className="text-gray-600 text-sm">{card.description}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="flex flex-col justify-center">
            <div className="space-y-6">
              {cards.slice(2).map((card, index) => (
                <div
                  key={index}
                  className={`p-6 rounded-lg shadow-md ${card.bgColor} flex flex-col items-start`}
                >
                  <div className="text-4xl mb-4">{card.icon}</div>
                  <h4 className="text-xl font-semibold text-gray-800 mb-2">
                    {card.title}
                  </h4>
                  <p className="text-gray-600 text-sm">{card.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
