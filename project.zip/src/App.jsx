import React from 'react'
import AboutSection from './pages/About'
import FAQSection from './pages/FaqPage'
import ServicesSection from './pages/ServicesSection'
import BlogCards from './pages/BlogCards'
import Header from './pages/Header'
import Navbar from './pages/Navbar'
import HeroSection from './pages/HeroSection'
import Services from './pages/NewSeicves'
import Footer from './pages/Footer '
import PartnersSection from './pages/PartnersSection'
import TestimonialSection from './pages/TestimonialSection '

import TestimonialSwiper from './pages/TestimonialSwiper'
const App = () => {
  return (
    <div>
        <Header/>
        <Navbar/>
        <HeroSection/>
        <Services/>
        <PartnersSection/>
      <AboutSection/>
      <BlogCards/>
      <FAQSection/>
      {/* <ServicesSection/> */}
      <TestimonialSection/>
      <TestimonialSwiper/>
      <Footer/>
    </div>
  )
}

export default App

